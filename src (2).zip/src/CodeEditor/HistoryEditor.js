import React, { useState, useEffect } from "react";
import ReactTypingEffect from "react-typing-effect";
import TypeWriterEffect from "react-typewriter-effect";
// import './App.css'
import "@chatscope/chat-ui-kit-styles/dist/default/styles.min.css";
import {
  MainContainer,
  ChatContainer,
  MessageList,
  Message,
  MessageInput,
  TypingIndicator,
} from "@chatscope/chat-ui-kit-react";

const API_KEY = "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";
// "Explain things like you would to a 10 year old learning how to code."
const systemMessage = {
  //  Explain things like you're talking to a software professional with 5 years of experience.
  role: "system",
  content: "You are a helpful assistant for programming code generation.",
};

function HistoryData({ historyCategory}) {
    console.log(historyCategory,"<<<<<<<<<<<<<<<<<<<<<<<<")

  







  const [messages, setMessages] = useState(historyCategory);

  


      
  
   

  return (
    <div>
      <div style={{ height: "85vh" }}>
        <MainContainer>
          <ChatContainer>
            <MessageList
              scrollBehavior="smooth"
              
            >
              {messages.map((message, i) => {
                console.log(message);
                return (
                  <Message
                    model={{
                      sender: message.sender,
                      type: "text",
                      position: "last",
                      direction: message.direction,
                      payload:
                        
                          <Message key={i} model={message} />
                        
                    }}
                  ></Message>
                );
              })}
            </MessageList>

         
           
          </ChatContainer>
        </MainContainer>
      </div>
    </div>
  );
}

export default HistoryData;
