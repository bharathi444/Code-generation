
import React, { Component,useState} from "react";
import CommonEditor from "./CommonEditor";
export default function Backend() {
 
  return (
    <div>
       <CommonEditor category={"Backend"} />
    </div>
  )
}
