import React from 'react'
import CommonEditor from './CommonEditor'

export default function DataBase() {
  return (
    <div><CommonEditor category={"DataBase"} /> </div>
  )
}

