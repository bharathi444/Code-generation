import React from 'react'
import CommonEditor from './CommonEditor'

export default function ExplainCode() {
  return (
    <div>
      <CommonEditor category={"True"}/>
      
    </div>
  )
}
