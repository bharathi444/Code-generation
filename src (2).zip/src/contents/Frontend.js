import React from 'react'
import CommonEditor from './CommonEditor'

export default function () {
  return (
    <div>
        <CommonEditor category={"Frontend"} />
    </div>
  )
}
