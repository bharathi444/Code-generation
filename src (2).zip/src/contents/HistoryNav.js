import React from 'react'
import CommonEditor from './CommonEditor'
import History from './History'

export default function HistoryNav() {
  return (
    <div>
      <History category={"Frontend"}/>
     
      
    </div>
  )
}
