export const ProgrammingLanguagesList = [
  { value: "C", label: "C", category: "Backend" },
  { value: "C#", label: "C#", category: "Backend" },
  { value: "C++", label: "C++", category: "Backend" },
  { value: "Java", label: "Java", category: "Backend" },
  { value: "Node", label: "Node", category: "Backend" },
  { value: "PHP", label: "PHP", category: "Backend" },
  { value: "Python", label: "Python", category: "Backend" },
  { value: "Perl", label: "Perl", category: "Backend" },
  { value: "Ruby", label: "Ruby", category: "Backend" },

  { value: "Flutter", label: "Flutter", category: "AppDev" },
  { value: "Java 11", label: "Java 11", category: "AppDev" },
  { value: "Kotlin", label: "Kotlin", category: "AppDev" },
  { value: "React Native", label: "React Native", category: "AppDev" },

  { value: "Angular JS", label: "Angular JS", category: "Frontend" },
  { value: "Bootstrap", label: "Bootstrap", category: "Frontend" },
  { value: "CSS", label: "CSS", category: "Frontend" },
  { value: "HTML", label: "HTML", category: "Frontend" },
  { value: "Jquery", label: "Jquery", category: "Frontend" },
  { value: "Next JS", label: "Next JS", category: "Frontend" },
  { value: "React", label: "React", category: "Frontend" },
  { value: "SCSS", label: "SCSS", category: "Frontend" },
  { value: "Tailwind CSS", label: "Tailwind CSS", category: "Frontend" },
  { value: "TypeScript", label: "TypeScript", category: "Frontend" },
  { value: "Vanilla JS", label: "Vanilla JS", category: "Frontend" },
  { value: "Vue 3", label: "Vue 3", category: "Frontend" },

  { value: "Mongo", label: "Mongo", category: "DataBase" },
  { value: "MySQL", label: "MySQL", category: "DataBase" },
  { value: "Oracle SQL", label: "OracleSQL", category: "DataBase" },
  { value: "PL/SQL", label: "PL/SQL", category: "DataBase" },
  { value: "PostgreSQL", label: "PostgreSQL", category: "DataBase" },
  { value: "SQL", label: "SQL", category: "DataBase" },
  { value: "SQLite", label: "SQLite", category: "DataBase" },
  { value: "T-SQL", label: "T-SQL", category: "DataBase" },

  { value: "Generate", label: "Generate", category: "Regex" },
  { value: "Explain", label: "Explain", category: "Regex" },

  

  



  
  

  
];
