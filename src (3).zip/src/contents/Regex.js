import React from 'react'
import CommonEditor from './CommonEditor'

export default function Regex() {
  return (
    <div><CommonEditor category={"Regex"} /></div>
  )
}
