import React from 'react'
import CommonEditor from './CommonEditor'

export default function AppDevelopment() {
  return (
    <div>
        <CommonEditor category={"AppDev"} />
    </div>
  )
}
