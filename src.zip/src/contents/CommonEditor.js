
import React, { Component,useState} from "react";
import ChatbotPackage from "../CodeEditor/CodeEditor";
import {ProgrammingLanguagesList} from "../CodeEditor/DropdownValues"
import Select from "react-select";
export default function CommonEditor({category}) {
  console.log(ProgrammingLanguagesList , "programming")
    const options =ProgrammingLanguagesList.filter((item) => item.category === category);
      const [selectedOption, setSelectedOption] = useState( options[0]);
      console.log("nkfjkg",selectedOption)
  return (
    <div>
          <div>
        
        <div className="condiv">
          <div className="chat-header">
            {" "}
           <div style={{marginLeft:'3%',fontWeight:'500'}}>Select Your Programming Language</div>
          <div style={{marginLeft:'3%'}}>
          <Select
                
                  defaultValue={options[0]}
                  options={options}
                  onChange={(values) => setSelectedOption(values)}
                />
          </div>
          </div>
        
          <div style={{ zIndex: 0, position: "relative", marginTop: "7%" }}>
          <hr></hr>
            <ChatbotPackage  selectedLanguage={selectedOption}/>
          </div>
        </div>
      </div>
    </div>
  )
}
