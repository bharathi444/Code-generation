import React, { Component } from 'react';
import Navitem from './Navitem';
import profilepic from '../img/profile_photo.jpg';

class Navbar extends Component {
    constructor(props)
    {
        super(props);
        this.state={
            'NavItemActive':''
        }
    }
    activeitem=(x)=>
    {
        if(this.state.NavItemActive.length>0){
            document.getElementById(this.state.NavItemActive).classList.remove('active');
        }
        this.setState({'NavItemActive':x},()=>{
            document.getElementById(this.state.NavItemActive).classList.add('active');
        });
    };
    render() {
        return (
            <nav className="glass">
            <img src={profilepic} className="profilepic"></img>
            <h2>Digital Garage <mark>Ai</mark></h2>
            <p>Your AI code assistant</p>
            <ul>
            <Navitem item="Frontend" tolink="/"  activec={this.activeitem}></Navitem>
            <Navitem item="Backend" tolink="/backend"  activec={this.activeitem}></Navitem>
            <Navitem item="App Development" tolink="/app-development"  activec={this.activeitem}></Navitem>
            <Navitem item="Database" tolink="/database"  activec={this.activeitem}></Navitem>
            <Navitem item="Regular Expression" tolink="/regex"  activec={this.activeitem}></Navitem>
            <Navitem item="Explain Code" tolink="/Explain-code"  activec={this.activeitem}></Navitem>
            </ul>
            </nav>
            )
        }
    }
    
    export default Navbar
    